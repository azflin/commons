import { Prompt, type PromptRef } from "@tui/component/prompt"
import { createEffect, createMemo, createSignal, onMount } from "solid-js"
import { Logo } from "../component/logo"
import { useSync } from "../context/sync"
import { Toast } from "../ui/toast"
import { useArgs } from "../context/args"
import { useRouteData } from "@tui/context/route"
import { usePromptRef } from "../context/prompt"
import { useLocal } from "../context/local"
import { TuiPluginRuntime } from "@/cli/cmd/tui/plugin/runtime"
import { useEditorContext } from "@tui/context/editor"
import { useTerminalDimensions } from "@opentui/solid"
import { useTuiConfig } from "../context/tui-config"
import { useTheme } from "@tui/context/theme"

const COMMONS_LOGO = [
  "                                                                               ",
  " ,p6\"bo   ,pW\"Wq.`7MMpMMMb.pMMMb.  `7MMpMMMb.pMMMb.  ,pW\"Wq.`7MMpMMMb.  ,pP\"Ybd",
  "6M'  OO  6W'   `Wb MM    MM    MM    MM    MM    MM 6W'   `Wb MM    MM  8I   `\"",
  "8M       8M     M8 MM    MM    MM    MM    MM    MM 8M     M8 MM    MM  `YMMMa.",
  "YM.    , YA.   ,A9 MM    MM    MM    MM    MM    MM YA.   ,A9 MM    MM  L.   I8",
  " YMbmd'   `Ybmd9'.JMML  JMML  JMML..JMML  JMML  JMML.`Ybmd9'.JMML  JMML.M9mmmP'",
]

let once = false
const placeholder = {
  normal: ["Fix a TODO in the codebase", "What is the tech stack of this project?", "Fix broken tests"],
  shell: ["ls -la", "git status", "pwd"],
}

export function Home() {
  const sync = useSync()
  const route = useRouteData("home")
  const promptRef = usePromptRef()
  const [ref, setRef] = createSignal<PromptRef | undefined>()
  const args = useArgs()
  const local = useLocal()
  const editor = useEditorContext()
  const dimensions = useTerminalDimensions()
  const tuiConfig = useTuiConfig()
  const { theme } = useTheme()
  const promptMaxWidth = createMemo(() => {
    const configured = tuiConfig.prompt?.max_width
    if (configured === "auto") return Math.max(75, Math.floor(dimensions().width * 0.7))
    return configured ?? 75
  })
  let sent = false

  onMount(() => {
    editor.clearSelection()
  })

  const bind = (r: PromptRef | undefined) => {
    setRef(r)
    promptRef.set(r)
    if (once || !r) return
    if (route.prompt) {
      r.set(route.prompt)
      once = true
      return
    }
    if (!args.prompt) return
    r.set({ input: args.prompt, parts: [] })
    once = true
  }

  // Wait for sync and model store to be ready before auto-submitting --prompt
  createEffect(() => {
    const r = ref()
    if (sent) return
    if (!r) return
    if (!sync.ready || !local.model.ready) return
    if (!args.prompt) return
    if (r.current.input !== args.prompt) return
    sent = true
    r.submit()
  })

  return (
    <>
      <box flexGrow={1} alignItems="center" paddingLeft={2} paddingRight={2}>
        <box flexGrow={1} minHeight={0} />
        {tuiConfig.commons_theme_experimental ? (
          <>
            <box flexShrink={0} alignItems="center">
              <TuiPluginRuntime.Slot name="home_logo" mode="replace">
                <box flexDirection="column" alignItems="center">
                  {COMMONS_LOGO.map((line) => (
                    <text content={line} style={{ fg: "#061BFF" }} />
                  ))}
                </box>
              </TuiPluginRuntime.Slot>
            </box>
            <box height={2} minHeight={0} flexShrink={1} />
            <box width="100%" maxWidth={promptMaxWidth()} zIndex={1000} flexShrink={0}>
              <TuiPluginRuntime.Slot name="home_prompt" mode="replace" ref={bind}>
                <Prompt ref={bind} right={<TuiPluginRuntime.Slot name="home_prompt_right" />} placeholders={placeholder} />
              </TuiPluginRuntime.Slot>
            </box>
          </>
        ) : (
          <>
            <box height={4} minHeight={0} flexShrink={1} />
            <box flexShrink={0}>
              <TuiPluginRuntime.Slot name="home_logo" mode="replace">
                <Logo />
              </TuiPluginRuntime.Slot>
            </box>
            <box height={1} minHeight={0} flexShrink={1} />
            <box width="100%" maxWidth={promptMaxWidth()} zIndex={1000} paddingTop={1} flexShrink={0}>
              <TuiPluginRuntime.Slot name="home_prompt" mode="replace" ref={bind}>
                <Prompt ref={bind} right={<TuiPluginRuntime.Slot name="home_prompt_right" />} placeholders={placeholder} />
              </TuiPluginRuntime.Slot>
            </box>
            <TuiPluginRuntime.Slot name="home_bottom" />
          </>
        )}
        <box flexGrow={1} minHeight={0} />
        <Toast />
      </box>
      <box width="100%" flexShrink={0}>
        <TuiPluginRuntime.Slot name="home_footer" mode="single_winner" />
      </box>
    </>
  )
}
